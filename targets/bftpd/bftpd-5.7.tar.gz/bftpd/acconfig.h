/* Define if we want to use PAM. */
#undef WANT_PAM

/* Define if we want to use GZIP. **/
#undef WANT_GZIP

/* Define if we want to use TAR. */
#undef WANT_TAR

/* Define if we can use getusershell(). */
#undef HAVE_GETUSERSHELL

@TOP@
